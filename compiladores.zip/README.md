## Bibliotecas utilizadas

sly

## Como rodar o programa?

### Preparação Virtual Env

Primeiro é necessário que o python esteja instalado na máquina. Em seguida execute os comandos abaixo em ordem:

`python -m venv venv`

`. ./venv/bin/activate`

`pip install -r requirements.txt`

### Execução dos testes

`python main.py teste.in.txt`
`python main.py teste_void.in.txt`
